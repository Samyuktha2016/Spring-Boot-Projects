async function loadReport() {
  const res = await fetch("http://localhost:8080/api/report/full");
  const reportData = await res.json();

  const tbody = document.querySelector("#reportTable tbody");
  tbody.innerHTML = "";

  reportData.forEach((r) => {
    const row = `
      <tr>
        <td>${r.name}</td>
        <td>${r.rollNo}</td>
        <td>${r.department}</td>
        <td>${r.attendanceCount}</td>
      </tr>
    `;
    tbody.innerHTML += row;
  });
}

loadReport();