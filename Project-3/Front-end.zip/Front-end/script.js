const msg = (text, success = true) => {
  const p = document.getElementById("message");
  p.textContent = text;
  p.style.color = success ? "#2e7d32" : "#c62828";
};

/* ---------- LOGIN ---------- */
async function login() {
  const username = document.getElementById("loginUsername").value;
  const password = document.getElementById("loginPassword").value;

  const res = await fetch("http://localhost:8080/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password })
  });
  const result = await res.text();
  msg(result, result.includes("successful"));
  if (result.includes("successful")) {
    setTimeout(() => (window.location = "dashboard.html"), 900);
  }
}

/* ---------- SIGNUP ---------- */
async function signup() {
  const username = document.getElementById("signupUsername").value;
  const password = document.getElementById("signupPassword").value;

  const res = await fetch("http://localhost:8080/api/auth/signup", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password })
  });
  const result = await res.text();
  msg(result, result.includes("successful"));
}

/* ---------- RESET ---------- */
async function resetPassword() {
  const username = document.getElementById("resetUsername").value;
  const newPassword = document.getElementById("newPassword").value;

  const res = await fetch(`http://localhost:8080/api/auth/reset?username=${username}&newPassword=${newPassword}`, {
    method: "PUT"
  });
  const result = await res.text();
  msg(result, result.includes("successful"));
}
