async function loadStudents() {
  const res = await fetch("http://localhost:8080/api/students/all");
  const students = await res.json();
  const form = document.getElementById("attendanceForm");
  form.innerHTML = "";
  students.forEach((s) => {
    form.innerHTML += `
      <div class="checkbox-item">
        <input type="checkbox" id="${s.id}" value="${s.id}">
        <label for="${s.id}">${s.name} (${s.rollNo})</label>
      </div>`;
  });
}

async function submitAttendance() {
  const ids = [...document.querySelectorAll("input[type='checkbox']:checked")].map(cb => cb.value);
  const today = new Date().toISOString().split("T")[0];
  for (let id of ids) {
    await fetch("http://localhost:8080/api/attendance/mark", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ studentId: id, date: today })
    });
  }
  alert("Attendance saved!");
  document.getElementById("attendanceForm").reset();
}

loadStudents();
