/* ---------- ADD STUDENT (add-student.html) ---------- */
const form = document.getElementById("studentForm");
if (form) {
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const name       = document.getElementById("name").value;
    const rollNo     = document.getElementById("rollNo").value;
    const department = document.getElementById("department").value;

    const res = await fetch("http://localhost:8080/api/students/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, rollNo, department })
    });
    const stu = await res.json();
    alert(`✅ Added: ${stu.name}`);
    form.reset();
  });
}

/* ---------- VIEW / EDIT / DELETE (view-students.html) ---------- */
async function loadStudents() {
  const res = await fetch("http://localhost:8080/api/students/all");
  const students = await res.json();
  const tbody = document.querySelector("#studentsTable tbody");
  if (!tbody) return;
  tbody.innerHTML = "";

  students.forEach((s) => {
    tbody.innerHTML += `
      <tr>
        <td>${s.name}</td>
        <td>${s.rollNo}</td>
        <td>${s.department}</td>
        <td>
          <button onclick=\"deleteStudent('${s.id}')\">🗑</button>
          <button onclick=\"editStudent('${s.id}','${s.name}','${s.rollNo}','${s.department}')\">✏️</button>
        </td>
      </tr>`;
  });
}

async function deleteStudent(id) {
  if (!confirm("Delete this student?")) return;
  await fetch(`http://localhost:8080/api/students/delete/${id}`, { method: "DELETE" });
  loadStudents();
}

function editStudent(id, name, roll, dept) {
  const newName = prompt("Name:", name);
  const newRoll = prompt("Roll No:", roll);
  const newDept = prompt("Department:", dept);
  if (newName && newRoll && newDept) {
    fetch(`http://localhost:8080/api/students/update/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newName, rollNo: newRoll, department: newDept })
    }).then(loadStudents);
  }
}

if (document.querySelector("#studentsTable")) loadStudents();
