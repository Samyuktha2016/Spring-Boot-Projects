async function loadStudents() {
  const res = await fetch("http://localhost:8080/api/students/all");
  const students = await res.json();
  const form = document.getElementById("attendanceForm");
  form.innerHTML = "";

  students.forEach((s) => {
    form.innerHTML += `
      <div>
        <input type="checkbox" id="${s.id}" value="${s.id}">
        <label for="${s.id}">${s.name} (${s.rollNo})</label>
      </div>
    `;
  });
}

async function submitAttendance() {
  const checkboxes = document.querySelectorAll("input[type='checkbox']");
  const presentIds = [];

  checkboxes.forEach((cb) => {
    if (cb.checked) presentIds.push(cb.value);
  });

  const today = new Date().toISOString().split("T")[0];

  const attendanceData = presentIds.map(id => ({
    studentId: id,
    date: today
  }));

  await fetch("http://localhost:8080/api/attendance/mark", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(attendanceData)
  });

  alert("Attendance recorded.");
}

loadStudents();
