document.getElementById("addStudentForm").addEventListener("submit", async function(e) {
  e.preventDefault();
  const name = document.getElementById("name").value;
  const rollNo = document.getElementById("rollNo").value;
  const department = document.getElementById("department").value;

  const res = await fetch("http://localhost:8080/api/students/add", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({name, rollNo, department})
  });

  const result = await res.text();
  alert(result);
});
