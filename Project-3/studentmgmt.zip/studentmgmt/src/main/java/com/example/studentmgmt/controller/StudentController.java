package com.example.studentmgmt.controller;
import com.example.studentmgmt.model.Student;
import com.example.studentmgmt.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/students")
@CrossOrigin
public class StudentController {
    @Autowired private StudentRepository repo;

    @PostMapping("/add")
    public Student addStudent(@RequestBody Student s) { return repo.save(s); }

    @GetMapping("/all")
    public List<Student> getAll() { return repo.findAll(); }

    @PutMapping("/update/{id}")
    public Student update(@PathVariable String id, @RequestBody Student s) {
        s.setId(id); return repo.save(s);
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable String id) { repo.deleteById(id); }
}

