package com.example.studentmgmt.controller;
import com.example.studentmgmt.model.Student;
import com.example.studentmgmt.repository.StudentRepository;
import com.example.studentmgmt.repository.AttendanceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/report")
@CrossOrigin
public class ReportController {
    @Autowired private StudentRepository studentRepo;
    @Autowired private AttendanceRepository attRepo;

    @GetMapping("/full")
    public List<Map<String, Object>> fullReport() {
        List<Map<String, Object>> report = new ArrayList<>();
        for (Student s : studentRepo.findAll()) {
            Map<String, Object> map = new HashMap<>();
            map.put("student", s);
            map.put("attendance", attRepo.findByStudentId(s.getId()));
            report.add(map);
        }
        return report;
    }
}
