package com.example.studentmgmt.controller;
import com.example.studentmgmt.model.Attendance;
import com.example.studentmgmt.repository.AttendanceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/attendance")
@CrossOrigin
public class AttendanceController {
    @Autowired private AttendanceRepository repo;

    @PostMapping("/mark")
    public Attendance mark(@RequestBody Attendance a) { return repo.save(a); }

    @GetMapping("/student/{studentId}")
    public List<Attendance> getByStudent(@PathVariable String studentId) {
        return repo.findByStudentId(studentId);
    }
}
