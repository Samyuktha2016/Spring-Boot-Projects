package com.example.studentmgmt.controller;
import com.example.studentmgmt.model.User;
import com.example.studentmgmt.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@CrossOrigin
public class LoginController {
    @Autowired private UserRepository userRepo;

    @PostMapping("/login")
    public String login(@RequestBody User user) {
        User existing = userRepo.findByUsername(user.getUsername());
        return (existing != null && existing.getPassword().equals(user.getPassword())) ?
            "Login successful!" : "Invalid credentials!";
    }

    @PostMapping("/signup")
    public String signup(@RequestBody User user) {
        if (userRepo.findByUsername(user.getUsername()) != null)
            return "User already exists!";
        userRepo.save(user);
        return "Signup successful!";
    }

    @PutMapping("/reset")
    public String reset(@RequestParam String username, @RequestParam String newPassword) {
        User user = userRepo.findByUsername(username);
        if (user == null) return "User not found!";
        user.setPassword(newPassword);
        userRepo.save(user);
        return "Password reset successful!";
    }
}
